###############################################################################
### Package trNB: all code for truncated NB glm, includes truncated Poisson ###
###############################################################################

### Written by William H. Aeberhard, May 2015
### contact: william.aeberhard@gmail.com


###########################################
### Support functions, not to be documented

h.poi.func <- function(x){ # vector x
  res <- x
  index <- which(x < 5)
  a <- 0.58178587
  b <- 0.04364283
  res[index] <- (1+a*x+b*x^2)[index]
  return(res)
} # END h.poi.func
hinv.poi.func <- function(x){ # vector x
  res <- x
  index <- which(x < 5)
  a <- 0.58178587
  b <- 0.04364283
  res[index] <- ((-a+sqrt(a^2+4*b*(x-1)))/(2*b))[index]
  return(res)
} # END hinv.poi.func
hderiv.poi.func <- function(x){ # vector x
  (1-exp(-x)-x*exp(-x))/(1-exp(-x))^2
} # END hderiv.poi.func
hderiv2.poi.func <- function(x){ # vector x
  (exp(-x)*((x-2)*(1-exp(-x))+2*x*exp(-x)))/(1-exp(-x))^3
} # END hderiv2.poi.func
h.func <- function(lambda,sigma){ # vector lambda, scalar sigma
  if (sigma==1){
    res <- lambda+1
  } else {
    sl1 <- (sigma*lambda+1)
    res <- lambda/(1-sl1^(-1/sigma))
  }
  return(res)
} # END h.func
hinv.func <- function(mu,sigma,lambda.range=c(1e-4,1e120)){ # scalar mu, scalar sigma, must be called within an sapply()
  if (sigma==1){
    res <- mu-1 # because h(lambda,1) = lambda+1
  } else {
    if (mu < 1.001){ # Poisson with lambda < 1e-3 has anyway 0.999 mass on 0.
      res <- mu-1 # arbitrarily close to 1, better than res=0 because of log applied on top.
    } else {
      tryit <- try(uniroot(f=function(l,sigma,mu){h.func(l,sigma)-mu},interval=lambda.range,sigma=sigma,mu=mu),T)
      if (class(tryit)!='try-error'){
        res <- tryit$root
        # } else {stop(paste("Couldn't find a lambda in (",lambda.range[1],',',lambda.range[2],') for the given mu = ',mu,'.',sep=''))}
      } else {
        res <- mu-1 # error most likely because sigma too large and mu too small, better than res=0 because of log.
        warning(paste("Couldn't find a lambda in (",lambda.range[1],',',lambda.range[2],') for the given mu = ',mu,'; return 0.',sep=''))}
    }
  }
  return(res)
} # END hinv.func
hderiv.func <- function(lambda,sigma){ # vector lambda, scalar sigma
  if (sigma==1){
    res <- rep(1,length(lambda))
  } else {
    sl1 <- (sigma*lambda+1)
    res <- (sl1^(1/sigma)-1-lambda/sl1)/(sl1^(1/sigma)-2+sl1^(-1/sigma))
  }
  return(res)
} # END hderiv.func
hderiv2.func <- function(lambda,sigma){ # vector lambda, scalar sigma
  if (sigma==1){
    res <- rep(0,length(lambda))
  } else {
    sl1 <- (sigma*lambda+1)
    res <- (4/sl1-2*sigma*lambda/sl1^2-2*sl1^(1/sigma-1)-2*sl1^(-1/sigma-1)+lambda*(sigma+1)*sl1^(1/sigma-2)+lambda*(sigma-1)*sl1^(-1/sigma-2))/(sl1^(1/sigma)-2+sl1^(-1/sigma))^2
  }
  return(res)
} # END hderiv2.func
loglik.sigma <- function(sigma,lambda,y){ # scalar sigma, vector lambda = h⁻¹(fixed mu, fixed sigma), vector y
  sl1 <- (sigma*lambda+1)
  invsig <- 1/sigma
  return(sum(lgamma(y+invsig)-lgamma(invsig)-log(sl1^invsig-1)+y*log(sigma*lambda/sl1))) # -lgamma(y+1)
} # END loglik.sigma


##########################################
### Support functions currently not in use

#   gr.loglik.sigma <- function(sigma,lambda,y){ # scalar sigma, vector lambda = h⁻¹(fixed mu, fixed sigma), vector y
#     sl1 <- (sigma*lambda+1)
#     invsig <- 1/sigma
#     return((-invsig^2)*sum(digamma(y+invsig)-digamma(invsig)-sigma*y/sl1-sl1^invsig/(sl1^invsig-1)*(log(sl1)-sigma*lambda/sl1)))
#   } # END gr.loglik.sigma


#####################################################
### Support functions, could be good to be documented

qtrPoi <- function(p,lambda){ # qpois() for truncated Poisson, lambda is mean of untruncated Poisson
  if (dpois(1,lambda)/(1-exp(-lambda))-p > 0){
    res <- 1
  } else {
    res <- uniroot(f=function(y){sum(dpois(1:y,lambda))/(1-exp(-lambda))-p},interval=c(1,10000))$root
  }
  return(round(res))
} # END qtrPoi
sigma.trNB <- function(lambda,y,minsig=1e-4,maxsig=0.9999,sigma.ini=0.5){ # estimates sigma given lambda=hinv(mu,sigma), where mu is mean of truncated NB
  # sigma could in principle be > 1, but still subject to an upper bound depending on min(lambda) to avoid negative variance => future work!
  res <- optimize(f=loglik.sigma,interval=c(minsig,maxsig),maximum=T,lambda=lambda,y=y) # no need for gr.loglik.sigma
  return(res$max)
} # END sigma.trNB
qtrNB <- function(p,lambda,sigma){ # qnbinom() for truncated NB, lambda is mean of untruncated NB
  if (dnbinom(1,mu=lambda,size=1/sigma)/(1-(sigma*lambda+1)^(-1/sigma))-p > 0){
    res <- 1
  } else {
    res <- uniroot(f=function(y){sum(dnbinom(1:y,mu=lambda,size=1/sigma))/(1-(sigma*lambda+1)^(-1/sigma))-p},interval=c(1,10000))$root
  }
  return(round(res))
} # END qtrNB


##########################################
### User-level functions, to be documented

truncPoi <- function(){ # truncated Poisson family object to call from glm()
  # adapted from Eva Cantoni's code, itself adapted from Barry and Welsh (2002).
  linkfun <- function(mu){log(hinv.poi.func(mu))}
  linkinv <- function(eta){h.poi.func(exp(eta))}
  variance <- function(mu){mu*(1+hinv.poi.func(mu)-mu)}
  validmu <- function(mu){all(mu>0)}
  dev.resids <- function(y,mu,wt){-2*wt*(y*log(hinv.poi.func(mu))-hinv.poi.func(mu)-log(1-exp(-hinv.poi.func(mu)))+ifelse(y==1,0,-y*log(hinv.poi.func(y))+hinv.poi.func(y)+log(1-exp(-hinv.poi.func(y)))))}
  aic <- function(y,n,mu,wt,dev){-2*sum(log(dpois(y,hinv.poi.func(mu))/(1-exp(-hinv.poi.func(mu))))*wt)}
  mu.eta <- function(eta){hderiv.poi.func(exp(eta))*exp(eta)}
  dvar <- function(mu){
    (1+hinv.poi.func(mu)-mu)+mu*(1/hderiv.poi.func(hinv.poi.func(mu))-1)
  }
  d2link <- function(mu){
    -1/(hinv.poi.func(mu))^2/(hderiv.poi.func(hinv.poi.func(mu)))^2-1/hinv.poi.func(mu)/(hderiv.poi.func(hinv.poi.func(mu)))^3*hderiv2.poi.func(hinv.poi.func(mu))
  }
  initialize <- expression({
    mustart <- y
    mustart[mustart==1] <- 1.1
  })
  structure(list(family="truncPoi",link="log of h^(-1)",linkfun=linkfun,linkinv=linkinv,variance=variance,dev.resids=dev.resids,aic=aic,mu.eta=mu.eta,dvar=dvar,d2link=d2link,initialize=initialize,validmu=validmu),class="family")
} # END truncPoi
rtrPoi <- function(n,mu){ # rpois() for truncated Poisson, mu is mean of truncated Poisson
  if (length(mu) > 1 & length(mu)!=n){
    stop('length(mu) should equal n, if not 1.')
  } else {
    unif.real <- runif(n,0,1)
    lambda <- sapply(mu,hinv.poi.func) # returns mean of untruncated Poisson
    return(mapply(qtrPoi,unif.real,lambda=lambda)) # simplifies to sapply if length(lambda)==1
  }
} # END rtrPoi
rtrNB <- function(n,mu,sigma){ # rnbinom() for truncated NB, mu is mean of truncated NB
  if (length(mu) > 1 & length(mu)!=n){
    stop('length(mu) should equal n, if not 1.')
  } else {
    unif.real <- runif(n,0,1)
    lambda <- sapply(mu,hinv.func,sigma=sigma) # returns mean of untruncated Poisson
    return(mapply(qtrNB,unif.real,lambda=lambda,sigma=sigma)) # simplifies to sapply if length(lambda)==1
  }
} # END rtrNB
truncNB <- function(sigma){ # family object to call from glm()
  #-----------------------------------------------------------------------------
  # Setup
  #-----------------------------------------------------------------------------
  if (missing(sigma)){stop("'sigma' must be specified")}
  if (length(sigma)>1){stop("length of 'sigma' should be 1.")}
  .Sigma <- sigma
  env <- new.env(parent=.GlobalEnv) # copied from MASS::negative.binomial
  assign(".Sigma",sigma,envir=env) # so that sigma is recognized everywhere without calling it
  #-----------------------------------------------------------------------------
  # Functions for truncNB family, tailored for stats::glm
  #-----------------------------------------------------------------------------
  linkfun <- function(mu){log(sapply(mu,hinv.func,sigma=.Sigma))}
  linkinv <- function(eta){h.func(exp(eta),.Sigma)}
  variance <- function(mu){
    lambda <- sapply(mu,hinv.func,sigma=.Sigma)
    return(as.numeric(mu-mu^2+mu*lambda+.Sigma*lambda^2))
  }
  validmu <- function(mu){all(mu>1)}
  # deviance components = -2*(loglik(hinv.func(mu))-loglik(hinv.func(y))) > 0
  dev.resids <- function(y,mu,wt){
    lambda.mu <- sapply(mu,hinv.func,sigma=.Sigma)
    lambda.y <- ifelse(y==1,0,sapply(y,hinv.func,sigma=.Sigma)) # faster
    return(-2*wt*(y*(log(.Sigma*lambda.mu)-log(.Sigma*lambda.mu+1))-log((.Sigma*lambda.mu+1)^(1/.Sigma)-1)-
                    ifelse(y==1,0,y*(log(.Sigma*lambda.y)-log(.Sigma*lambda.y+1))-log((.Sigma*lambda.y+1)^(1/.Sigma)-1))))
  }
  # aic = -2*loglik(hinv.func(mu))
  aic <- function(y,n,mu,wt,dev){
    lambda <- sapply(mu,hinv.func,sigma=.Sigma)
    return(-2*as.numeric(crossprod(log(dnbinom(x=y,mu=lambda,size=1/.Sigma)/(1-(.Sigma*lambda+1)^(-1/.Sigma))),wt)))
  }
  # derivinvlink
  mu.eta <- function(eta){hderiv.func(exp(eta),.Sigma)*exp(eta)}
  # derivative of V(mu_i) wrt mu_i
  dvar <- function(mu){
    lambda <- sapply(mu,hinv.func,sigma=.Sigma)
    hderiv.lambda <- hderiv.func(lambda,.Sigma)
    return(1-2*mu+lambda+mu/hderiv.lambda+2*.Sigma*lambda/hderiv.lambda)
  }
  # second derivative of link(mu_i) wrt mu_i
  d2link <- function(mu){
    lambda <- sapply(mu,hinv.func,sigma=.Sigma)
    hderiv.lambda <- hderiv.func(lambda,.Sigma)
    return(-1/(lambda*hderiv.lambda)^2-hderiv2.func(lambda,.Sigma)/(lambda*hderiv.lambda^3))
  }
  initialize <- expression({
    mustart <- y
    mustart[mustart==1] <- 1.01
  })
  #-----------------------------------------------------------------------------
  # Output
  #-----------------------------------------------------------------------------
  structure(list(family=paste("truncNB(sigma=",round(.Sigma,2),')',sep=''),link="log of h^(-1)(sigma)",linkfun=linkfun,linkinv=linkinv,variance=variance,dev.resids=dev.resids,aic=aic,mu.eta=mu.eta,dvar=dvar,d2link=d2link,initialize=initialize,validmu=validmu),class="family")
} # END truncNB
glm.trNB <- function(formula,minsig=1e-4,maxsig=0.9999,sigma.ini=0.5,tol=1e-4,maxit=50,...){ # wrapper for glm() with family=truncNB
  # sigma and beta estimated iteratively
  # sigma constrained to (1e-4,0.9999) to avoid negative variances for low mu
  #-----------------------------------------------------------------------------
  # Setup
  #-----------------------------------------------------------------------------
  mf <- model.frame(formula=formula,...)
  y <- model.response(mf) # extract response vector from formula
  trfit <- glm(formula=formula,family='truncPoi',...) # initial truncated Poisson fit
  mu <- trfit$fitted
  lambda <- sapply(mu,hinv.func,sigma=sigma.ini)
  sigma <- sigma.trNB(lambda=lambda,y=y,minsig=minsig,maxsig=maxsig,sigma.ini=sigma.ini) # initial sigma
  #-----------------------------------------------------------------------------
  # Evaluation and output
  #-----------------------------------------------------------------------------
  it <- 0L
  loglkhd1 <- loglik.sigma(sigma,lambda,y)
  loglkhd0 <- loglkhd1+tol+1
  while (abs(loglkhd1-loglkhd0)>tol & it<maxit){
    loglkhd0 <- loglkhd1
    # update mu
    trfit <- glm(formula=formula,family=truncNB(sigma),...)
    mu <- trfit$fitted
    lambda <- sapply(mu,hinv.func,sigma=sigma)
    # update sigma
    sigma <- sigma.trNB(lambda=lambda,y=y,minsig=minsig,maxsig=maxsig,sigma.ini=sigma)
    loglkhd1 <- loglik.sigma(sigma,lambda,y)
    it <- it+1
  }
  if (it==maxit){warning('Maximum number of iterations reached.')}
  return(list('glmobj'=trfit,'sigma'=sigma)) # returns object of class glm along with estimated sigma
} # END glm.trnb
gam.trNB <- function(formula,minsig=1e-4,maxsig=0.9999,sigma.ini=0.5,tol=1e-4,maxit=50,...){ # wrapper for gam() with family=truncNB
  # sigma and beta estimated iteratively
  # sigma constrained to (1e-4,0.9999) to avoid negative variances for low mu
  #-----------------------------------------------------------------------------
  # Setup
  #-----------------------------------------------------------------------------
  gp <- interpret.gam(formula)
  mf <- model.frame(gp$fake.formula,...)
  y <- model.response(mf) # extract response vector from formula
  trfit <- gam(formula=formula,family='truncPoi',optimizer='perf',...) # initial truncated Poisson fit
  mu <- trfit$fitted
  lambda <- sapply(mu,hinv.func,sigma=sigma.ini)
  sigma <- sigma.trNB(lambda=lambda,y=y,minsig=minsig,maxsig=maxsig,sigma.ini=sigma.ini) # initial sigma
  #-----------------------------------------------------------------------------
  # Evaluation and output
  #-----------------------------------------------------------------------------
  it <- 0L
  loglkhd1 <- loglik.sigma(sigma,lambda,y)
  loglkhd0 <- loglkhd1+tol+1
  while (abs(loglkhd1-loglkhd0)>tol & it<maxit){
    loglkhd0 <- loglkhd1
    # update mu
    trfit <- gam(formula=formula,family=truncNB(sigma),optimizer='perf',...)
    mu <- trfit$fitted
    lambda <- sapply(mu,hinv.func,sigma=sigma)
    # update sigma
    sigma <- sigma.trNB(lambda=lambda,y=y,minsig=minsig,maxsig=maxsig,sigma.ini=sigma)
    loglkhd1 <- loglik.sigma(sigma,lambda,y)
    it <- it+1
  }
  if (it==maxit){warning('Maximum number of iterations reached.')}
  return(list('gamobj'=trfit,'sigma'=sigma)) # returns object of class gam along with estimated sigma
} # END gam.trnb
